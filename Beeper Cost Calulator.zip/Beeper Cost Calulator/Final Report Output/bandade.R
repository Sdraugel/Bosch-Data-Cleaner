#Import Statements
library(data.table)
library(dplyr)
library(tcltk)
library(xlsx)
library(tcltk)
library(tcltk2)

###########################################
#Start of data cleaning
###########################################

#Set the directory where the data is stored
#####Put the folder name below#####
directory = tk_choose.dir(default = "", caption = "Select the working directory")

setwd(directory)
df1 = read.xlsx("Finished_Report.xlsx", 1, row.names = NULL)
df2 = read.csv("HR.csv", row.names = NULL )
colnames(df2)[1] = "num"
colnames(df2)[2] = "pers"
colnames(df2)[3] = "Holder"
colnames(df2)[4] = "Actual.Cost.Center"

df1 = as.data.frame(df1[order(df1$Holder),], stringsAsFactors = FALSE)
df2 = as.data.frame(df2[order(df2$Holder),], stringsAsFactors = FALSE)

df1$PagerPhoneNumber[] = lapply(df1$PagerPhoneNumber, as.character)
df1$ReferenceField3[] = lapply(df1$ReferenceField3, as.character)
df1$Actual.Cost.Center[] = lapply(df1$Actual.Cost.Center, as.character)

df1$ReferenceField3[as.character(df1$PagerPhoneNumber) != "Finance" & as.character(df1$ReferenceField3) == "Finance"] <- "ugh"
df1$Actual.Cost.Center[as.character(df1$PagerPhoneNumber) != "Finance" & as.character(df1$Actual.Cost.Center) == "Finance"] <- "ugh"

df2$Holder = toupper(df2$Holder)
keeps = c(3,4)

df2_subset = subset(df2, select = keeps, stringsAsFacotrs = FALSE)

df_merge = merge(df2_subset, df1, by = "Holder", all = TRUE)

test = df_merge
test$Actual.Cost.Center.y <- as.character(test$Actual.Cost.Center.y)

test$Actual.Cost.Center.x[is.na(test$Actual.Cost.Center.x)] <- "blank"
test$Actual.Cost.Center.y[is.na(test$Actual.Cost.Center.y)] <- "blank"

test[] <- lapply(test, as.character)

indx <- test$Actual.Cost.Center.x == "blank"

test$Actual.Cost.Center.x[indx] <- test$Actual.Cost.Center.y[indx]

test <- as.data.frame(test)
test$Actual.Cost.Center.y <- NULL
test$Totals <- NULL

test <- test[- grep("TOTAL", test$Actual.Cost.Center.x),]
test <- na.omit(test)

test$TotalAmount <- as.numeric(test$TotalAmount)

totals <- aggregate(test$TotalAmount, by=list(Actual.Cost.Center.x = test$Actual.Cost.Center.x), FUN=sum)
colnames(totals)[2] = "Totals"
totals$Totals <- as.numeric(as.character(as.factor(totals$Totals)))
totals$Actual.Cost.Center.x <- as.numeric(as.character(as.factor(totals$Actual.Cost.Center.x)))

#Get a grand total for the total cost
GrandTotal <- colSums(totals, na.rm = FALSE)
GrandTotal <- as.data.frame(GrandTotal)

#remove the uneeded row
GrandTotal <- GrandTotal[-1,]
GrandTotal <- as.data.frame(GrandTotal)
colnames(GrandTotal)[1] = "Totals"

#Merge totals and subset_df together
merge_subset_df <- rbind(test, totals, fill = TRUE)
merge_subset_df <- rbind(merge_subset_df, GrandTotal, fill = TRUE)

